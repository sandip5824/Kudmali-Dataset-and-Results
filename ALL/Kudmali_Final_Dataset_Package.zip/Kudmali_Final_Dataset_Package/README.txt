KUDMALI FINAL DATASET PACKAGE — STEP 16
Prepared 2026-09-03

FINAL GOLD
106 verified Gold Candidate records; 104 unique words; 43 roots.
This is a conservative verified subset. Review/uncertain records are not silently promoted.

SEQUENCE
21 validated B/M/E/S records. Missing/pending representations are not fabricated.

BOUNDARY
130 validated 0/1 boundary rows. Pending/non-surface-concatenative cases remain excluded from direct binary reconstruction.

WORD-LEVEL SPLIT
TRAIN 85 records / 83 words
DEV 11 records / 11 words
TEST 10 records / 10 words
Seed 20260903; zero word leakage.
Manifest SHA-256: 8683fc6f78a8e5952724f481e6ad5ddb5b944aa19aad0ae5b207c822cc6d48f

ROOT-DISJOINT SPLIT
TRAIN 85 records / 27 roots
DEV 11 records / 8 roots
TEST 10 records / 8 roots
Zero root overlap.
Manifest SHA-256: 10857f52618c959623407fa9f5c330470def5f3095c7a8c9e44a9430d17cfdd3

MORFESSOR
Separate Word-level and Root-disjoint TRAIN vocabularies are supplied.
The executed baseline was a deterministic fallback because official Morfessor 2.0.6 installation was unavailable in the sandbox. Do not report fallback results as official Morfessor 2.0.6.

ANNOTATION GUIDE
Original v3 guide preserved.

DATA DICTIONARY
Defines fields used across Gold, sequence, boundary and split datasets.

PAPER-READINESS NOTE
Before final submission, complete the root-disjoint reruns and use those results for the final model comparison. Current supervised results are representation-limited.
